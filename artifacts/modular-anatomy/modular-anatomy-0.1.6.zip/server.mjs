// src/marinara/service.ts
import { randomUUID } from "node:crypto";

// data/humanoid-basic.json
var humanoid_basic_default = {
  template_id: "humanoid-functional-basic",
  name: "Basic humanoid",
  units: {
    length: "cm"
  },
  parts: [
    {
      part_id: "body",
      parent_id: null,
      placement: null,
      name: "Body",
      roles: ["aggregate"],
      attributes: {
        geometry: { length: 180, width: 50, depth: 30, shape: "aggregate" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: []
      }
    },
    {
      part_id: "torso",
      parent_id: "body",
      placement: { horizontal: 50, vertical: 65, depth: 50 },
      name: "Torso",
      roles: ["trunk"],
      attributes: {
        geometry: { length: 60, width: 40, depth: 25, shape: "tapered_box" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: []
      }
    },
    {
      part_id: "arm.left",
      parent_id: "torso",
      placement: { horizontal: 0, vertical: 90, depth: 50 },
      name: "Left arm",
      roles: ["limb"],
      attributes: {
        geometry: { length: 60, width: 10, depth: 10, shape: "tapered_cylinder" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: ["manipulation"]
      }
    },
    {
      part_id: "arm.right",
      parent_id: "torso",
      placement: { horizontal: 100, vertical: 90, depth: 50 },
      name: "Right arm",
      roles: ["limb"],
      attributes: {
        geometry: { length: 60, width: 10, depth: 10, shape: "tapered_cylinder" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: ["manipulation"]
      }
    },
    {
      part_id: "leg.left",
      parent_id: "torso",
      placement: { horizontal: 25, vertical: 0, depth: 50 },
      name: "Left leg",
      roles: ["limb"],
      attributes: {
        geometry: { length: 90, width: 15, depth: 15, shape: "tapered_cylinder" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: ["locomotion"]
      }
    },
    {
      part_id: "leg.right",
      parent_id: "torso",
      placement: { horizontal: 75, vertical: 0, depth: 50 },
      name: "Right leg",
      roles: ["limb"],
      attributes: {
        geometry: { length: 90, width: 15, depth: 15, shape: "tapered_cylinder" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: ["locomotion"]
      }
    }
  ]
};

// data/anatomy-effects.json
var anatomy_effects_default = [
  {
    effect_id: "temporary-arm-growth",
    name: "Temporary arm growth",
    description: "Adds three centimetres to the selected arm for two native game hours.",
    eligible_part_ids: ["arm.left", "arm.right"],
    operations: [
      { field: "geometry.length", op: "add", value: 3 }
    ],
    lifetime: { kind: "temporary", duration_minutes: 120 }
  },
  {
    effect_id: "temporary-scales",
    name: "Temporary scales",
    description: "Adds a scale covering and changes stiffness for two native game hours.",
    eligible_part_ids: ["arm.left", "arm.right"],
    operations: [
      { field: "surface.coverings", op: "set", value: ["skin", "scales"] },
      { field: "mechanics.stiffness", op: "set", value: 0.8 }
    ],
    lifetime: { kind: "temporary", duration_minutes: 120 }
  },
  {
    effect_id: "permanent-composition-shift",
    name: "Permanent composition shift",
    description: "Sets the selected arm's authored muscle and fat proportions.",
    eligible_part_ids: ["arm.left", "arm.right"],
    operations: [
      { field: "composition.muscle", op: "set", value: 0.45 },
      { field: "composition.fat", op: "set", value: 0.25 }
    ],
    lifetime: { kind: "permanent" }
  }
];

// data/capability-demo.json
var capability_demo_default = {
  bundle_id: "basic-capabilities-demo",
  template_id: "humanoid-functional-basic",
  parts: [
    {
      part_id: "organ.demo",
      parent_id: "torso",
      placement: { horizontal: 50, vertical: 25, depth: 50 },
      name: "Demo gland",
      roles: ["organ"],
      attributes: {
        geometry: { length: 4, width: 3, depth: 2, shape: "ellipsoid" },
        composition: { other_soft_tissue: 1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["tissue"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: ["produce", "store"]
      }
    }
  ],
  materials: [
    { material_id: "demo-fluid", name: "Demo fluid", unit: "ml" }
  ],
  capabilities: [
    {
      capability_id: "arm.left.manipulator",
      part_id: "arm.left",
      name: "Left arm manipulation",
      type: "manipulator",
      properties: { volume_factor: 1, precision: 0.8, reach_per_cm: 1, grip_units_per_cm3: 1e-3 }
    },
    {
      capability_id: "arm.right.manipulator",
      part_id: "arm.right",
      name: "Right arm manipulation",
      type: "manipulator",
      properties: { volume_factor: 1, precision: 0.8, reach_per_cm: 1, grip_units_per_cm3: 1e-3 }
    },
    {
      capability_id: "organ.demo.reservoir",
      part_id: "organ.demo",
      name: "Demo fluid reservoir",
      type: "reservoir",
      properties: { volume_factor: 0.5235987755982988, material_id: "demo-fluid", capacity_units_per_cm3: 0.5 }
    },
    {
      capability_id: "organ.demo.producer",
      part_id: "organ.demo",
      name: "Demo fluid production",
      type: "producer",
      properties: { volume_factor: 0.5235987755982988, material_id: "demo-fluid", destination_reservoir_id: "organ.demo.reservoir", rate_units_per_cm3_per_minute: 1e-3 }
    }
  ]
};

// src/time.ts
function toGameMinutes(time) {
  return (time.day - 1) * 24 * 60 + time.hour * 60 + time.minute;
}

// src/anatomy.ts
function clone(value) {
  return structuredClone(value);
}
function applyNumeric(current, operation) {
  switch (operation.op) {
    case "set":
      return operation.value;
    case "add":
      return current + operation.value;
    case "subtract":
      return current - operation.value;
    case "multiply":
      return current * operation.value;
  }
}
function applyOperation(part, operation) {
  switch (operation.field) {
    case "geometry.length":
      part.attributes.geometry.length = applyNumeric(part.attributes.geometry.length, operation);
      return;
    case "geometry.width":
      part.attributes.geometry.width = applyNumeric(part.attributes.geometry.width, operation);
      return;
    case "geometry.depth":
      part.attributes.geometry.depth = applyNumeric(part.attributes.geometry.depth, operation);
      return;
    case "placement.horizontal":
      part.placement = { ...part.placement, horizontal: applyNumeric(part.placement.horizontal, operation) };
      return;
    case "placement.vertical":
      part.placement = { ...part.placement, vertical: applyNumeric(part.placement.vertical, operation) };
      return;
    case "placement.depth":
      part.placement = { ...part.placement, depth: applyNumeric(part.placement.depth, operation) };
      return;
    case "geometry.shape":
      part.attributes.geometry.shape = operation.value;
      return;
    case "composition":
      part.attributes.composition = clone(operation.value);
      return;
    case "placement":
      part.placement = clone(operation.value);
      return;
    case "mechanics.stiffness":
      part.attributes.mechanics.stiffness = applyNumeric(part.attributes.mechanics.stiffness, operation);
      return;
    case "surface.coverings":
      part.attributes.surface.coverings = [...operation.value];
      return;
    case "surface.color":
      part.attributes.surface.color = operation.value;
      return;
    case "surface.texture":
      part.attributes.surface.texture = operation.value;
      return;
    case "surface.markings":
      part.attributes.surface.markings = [...operation.value];
      return;
    case "roles":
      part.roles = [...operation.value];
      return;
    case "functions":
      part.attributes.functions = [...operation.value];
      return;
    default: {
      const material = operation.field.slice("composition.".length);
      const composition = part.attributes.composition;
      composition[material] = applyNumeric(composition[material], operation);
    }
  }
}
function copyPart(part) {
  return clone(part);
}
function copyParts(parts) {
  return parts.map(copyPart);
}
function createAnatomy(parts) {
  return {
    parts: copyParts(parts),
    statuses: []
  };
}
function changePermanentPart(anatomy, part_id, operations) {
  const parts = copyParts(anatomy.parts);
  const target = parts.find((part) => part.part_id === part_id);
  for (const operation of operations) {
    applyOperation(target, operation);
  }
  return {
    parts,
    statuses: clone(anatomy.statuses)
  };
}
function applyStatus(anatomy, status) {
  return {
    parts: clone(anatomy.parts),
    statuses: [...clone(anatomy.statuses), clone(status)]
  };
}
function removeStatus(anatomy, status_id) {
  return {
    parts: clone(anatomy.parts),
    statuses: anatomy.statuses.filter((status) => status.status_id !== status_id).map(clone)
  };
}
function statusIsActive(status, now) {
  const current = toGameMinutes(now);
  const starts = toGameMinutes(status.starts_at);
  const expires = status.expires_at === null ? null : toGameMinutes(status.expires_at);
  return current >= starts && (expires === null || current < expires);
}
function resolveAnatomy(anatomy, now) {
  const parts = copyParts(anatomy.parts);
  for (const status of anatomy.statuses) {
    if (!statusIsActive(status, now)) {
      continue;
    }
    const target = parts.find((part) => part.part_id === status.part_id);
    for (const operation of status.operations) {
      applyOperation(target, operation);
    }
  }
  return parts;
}

// src/templates.ts
function createAnatomyFromTemplate(template) {
  return createAnatomy(template.parts);
}

// src/descriptions.ts
var THIRD = 100 / 3;
var TWO_THIRDS = 100 * 2 / 3;
function formatNumber(value) {
  return value.toFixed(6).replace(/\.?(0+)$/, "");
}
function humanize(value) {
  return value.replaceAll("_", " ");
}
function list(values) {
  return values.length === 0 ? "none" : values.map(humanize).join(", ");
}
function positionLabel(value, low, middle, high) {
  if (value === 0) return `${low} edge`;
  if (value === 100) return `${high} edge`;
  if (value < THIRD) return low;
  if (value < TWO_THIRDS) return middle;
  return high;
}
function positionText(part, parent) {
  const placement = part.placement;
  return `Attaches to ${parent.name} (${parent.part_id}) at horizontal ${formatNumber(placement.horizontal)}% (${positionLabel(placement.horizontal, "left", "central", "right")}), vertical ${formatNumber(placement.vertical)}% (${positionLabel(placement.vertical, "lower", "middle", "upper")}), depth ${formatNumber(placement.depth)}% (${positionLabel(placement.depth, "posterior", "central-depth", "anterior")}).`;
}
function proportionText(part, parent) {
  const geometry = part.attributes.geometry;
  const parentGeometry = parent.attributes.geometry;
  const length = geometry.length / parentGeometry.length * 100;
  const width = geometry.width / parentGeometry.width * 100;
  const depth = geometry.depth / parentGeometry.depth * 100;
  return `Bounding-envelope proportions relative to ${parent.name} (${parent.part_id}): length ${formatNumber(length)}%, width ${formatNumber(width)}%, depth ${formatNumber(depth)}%.`;
}
function compositionText(part) {
  const entries = Object.entries(part.attributes.composition).sort(([left], [right]) => left.localeCompare(right)).map(([material, proportion]) => `${humanize(material)} ${formatNumber(proportion * 100)}%`);
  return entries.length === 0 ? "Composition: none." : `Composition: ${entries.join(", ")}.`;
}
function describeParts(parts) {
  const byId = new Map(parts.map((part) => [part.part_id, part]));
  return parts.map((part) => {
    const parent = part.parent_id === null ? null : byId.get(part.parent_id);
    const geometry = part.attributes.geometry;
    const placement = parent === null ? "This is the body hierarchy root." : positionText(part, parent);
    const proportions = parent === null ? "" : ` ${proportionText(part, parent)}`;
    const text = [
      `${part.name} (${part.part_id}).`,
      placement,
      `Approximate bounding dimensions: length ${formatNumber(geometry.length)} cm, width ${formatNumber(geometry.width)} cm, depth ${formatNumber(geometry.depth)} cm; shape: ${humanize(geometry.shape)}.`,
      proportions.trim(),
      compositionText(part),
      `Stiffness: ${formatNumber(part.attributes.mechanics.stiffness * 100)}%.`,
      `Surface: coverings ${list(part.attributes.surface.coverings)}, color ${part.attributes.surface.color}, texture ${humanize(part.attributes.surface.texture)}, markings ${list(part.attributes.surface.markings)}.`,
      `Roles: ${list(part.roles)}. Functions: ${list(part.attributes.functions)}.`
    ].filter((section) => section.length > 0).join(" ");
    return { part_id: part.part_id, parent_id: part.parent_id, text };
  });
}

// src/effects.ts
function applyAnatomyEffect(anatomy, definition, part_id, context) {
  if (definition.lifetime.kind === "permanent") {
    return changePermanentPart(anatomy, part_id, definition.operations);
  }
  const status = {
    status_id: context.status_id,
    part_id,
    starts_at: context.now,
    expires_at: addGameMinutes(context.now, definition.lifetime.duration_minutes),
    operations: definition.operations
  };
  return applyStatus(anatomy, status);
}
function addGameMinutes(now, duration_minutes) {
  const total = toGameMinutes(now) + duration_minutes;
  const day = Math.floor(total / 1440) + 1;
  const day_minutes = total % 1440;
  return {
    day,
    hour: Math.floor(day_minutes / 60),
    minute: day_minutes % 60
  };
}

// src/capabilities/bundle.ts
function installCapabilityBundle(anatomy, state, bundle) {
  if (state.installed_bundle_ids.includes(bundle.bundle_id)) return { anatomy, capabilities: state };
  const existingState = state;
  const quantities = { ...existingState.reservoir_quantities };
  for (const capability of bundle.capabilities) {
    if (capability.type === "reservoir") quantities[capability.capability_id] ??= 0;
  }
  const installedState = {
    ...existingState,
    definitions: [...existingState.definitions, ...structuredClone(bundle.capabilities)],
    materials: [...existingState.materials, ...structuredClone(bundle.materials)],
    reservoir_quantities: quantities,
    installed_bundle_ids: [...existingState.installed_bundle_ids, bundle.bundle_id]
  };
  return {
    anatomy: {
      parts: structuredClone([...anatomy.parts, ...bundle.parts]),
      statuses: structuredClone(anatomy.statuses)
    },
    capabilities: installedState
  };
}

// src/capabilities/resolve.ts
function resolveCapabilities(definitions, parts) {
  const partsById = new Map(parts.map((part) => [part.part_id, part]));
  return definitions.map((definition) => {
    const part = partsById.get(definition.part_id);
    const geometry = part.attributes.geometry;
    const volume_cm3 = geometry.length * geometry.width * geometry.depth * definition.properties.volume_factor;
    const common = {
      capability_id: definition.capability_id,
      part_id: definition.part_id,
      part_name: part.name,
      name: definition.name,
      volume_cm3
    };
    switch (definition.type) {
      case "manipulator":
        return {
          ...common,
          type: definition.type,
          precision: definition.properties.precision,
          reach_cm: geometry.length * definition.properties.reach_per_cm,
          grip_units: volume_cm3 * definition.properties.grip_units_per_cm3
        };
      case "reservoir":
        return {
          ...common,
          type: definition.type,
          material_id: definition.properties.material_id,
          capacity: volume_cm3 * definition.properties.capacity_units_per_cm3
        };
      case "producer":
        return {
          ...common,
          type: definition.type,
          material_id: definition.properties.material_id,
          destination_reservoir_id: definition.properties.destination_reservoir_id,
          rate_per_minute: volume_cm3 * definition.properties.rate_units_per_cm3_per_minute
        };
    }
  });
}

// src/capabilities/state.ts
function createCapabilityState() {
  return {
    definitions: [],
    materials: [],
    reservoir_quantities: {},
    last_evaluated_at: null,
    installed_bundle_ids: []
  };
}
function advanceCapabilities(anatomy, state, now) {
  const currentMinutes = toGameMinutes(now);
  if (state.last_evaluated_at === null) {
    return { ...state, reservoir_quantities: { ...state.reservoir_quantities }, last_evaluated_at: structuredClone(now) };
  }
  const previousMinutes = toGameMinutes(state.last_evaluated_at);
  if (currentMinutes === previousMinutes) return state;
  const boundaries = /* @__PURE__ */ new Set([previousMinutes, currentMinutes]);
  for (const status of anatomy.statuses) {
    const start = toGameMinutes(status.starts_at);
    if (start > previousMinutes && start < currentMinutes) boundaries.add(start);
    if (status.expires_at !== null) {
      const expiry = toGameMinutes(status.expires_at);
      if (expiry > previousMinutes && expiry < currentMinutes) boundaries.add(expiry);
    }
  }
  const orderedBoundaries = [...boundaries].sort((left, right) => left - right);
  const quantities = { ...state.reservoir_quantities };
  for (let index = 0; index < orderedBoundaries.length - 1; index += 1) {
    const segmentStart = orderedBoundaries[index];
    const segmentEnd = orderedBoundaries[index + 1];
    const elapsedMinutes = segmentEnd - segmentStart;
    const parts = resolveAnatomy(anatomy, fromGameMinutes(segmentStart));
    settleSegment(state, parts, quantities, elapsedMinutes);
  }
  return {
    ...state,
    reservoir_quantities: quantities,
    last_evaluated_at: structuredClone(now)
  };
}
function settleSegment(state, parts, quantities, elapsedMinutes) {
  const resolved = resolveCapabilities(state.definitions, parts);
  const reservoirs = new Map(resolved.filter((capability) => capability.type === "reservoir").map((capability) => [capability.capability_id, capability]));
  const rates = /* @__PURE__ */ new Map();
  for (const producer of resolved) {
    if (producer.type !== "producer") continue;
    rates.set(producer.destination_reservoir_id, (rates.get(producer.destination_reservoir_id) ?? 0) + producer.rate_per_minute);
  }
  for (const [reservoirId, reservoir] of reservoirs) {
    const quantity = quantities[reservoirId] ?? 0;
    const remaining = reservoir.capacity - quantity;
    if (remaining <= 0) continue;
    const produced = (rates.get(reservoirId) ?? 0) * elapsedMinutes;
    quantities[reservoirId] = quantity + Math.min(remaining, produced);
  }
}
function fromGameMinutes(minutes) {
  const dayMinutes = 24 * 60;
  const day = Math.floor(minutes / dayMinutes) + 1;
  const withinDay = minutes % dayMinutes;
  return {
    day,
    hour: Math.floor(withinDay / 60),
    minute: withinDay % 60
  };
}

// src/marinara/anatomy-body.ts
var capabilityDemo = capability_demo_default;
function buildAnatomyBody(data, subject, game_time, available_effects) {
  const effective_parts = game_time ? resolveEffectiveParts(data, game_time) : null;
  const baseline_descriptions = describeParts(data.anatomy.parts);
  const effective_descriptions = effective_parts ? describeParts(effective_parts) : null;
  return {
    state: game_time ? "ready" : "clock_uninitialized",
    game_id: data.game_id,
    subject,
    template_id: data.template_id,
    game_time,
    permanent: data.anatomy,
    effective_parts,
    baseline_descriptions,
    effective_descriptions,
    effects: available_effects,
    statuses: data.anatomy.statuses,
    capabilities: data.capabilities,
    baseline_capabilities: resolveCapabilities(data.capabilities.definitions, data.anatomy.parts),
    effective_capabilities: effective_parts ? resolveCapabilities(data.capabilities.definitions, effective_parts) : null,
    capability_demo_available: data.template_id === capabilityDemo.template_id && !data.capabilities.installed_bundle_ids.includes(capabilityDemo.bundle_id)
  };
}
function resolveEffectiveParts(data, game_time) {
  return resolveAnatomy(data.anatomy, game_time);
}

// src/marinara/service.ts
var PACKAGE_ID = "modular-anatomy";
var DOCUMENT_KIND = "character-anatomy";
var dataset = humanoid_basic_default;
var effects = anatomy_effects_default;
var capabilityDemo2 = capability_demo_default;
var AnatomyService = class {
  api;
  package_id;
  constructor(api, package_id = PACKAGE_ID) {
    this.api = api;
    this.package_id = package_id;
  }
  async getContext(chat_id) {
    const chat = await this.requireChat(chat_id);
    const metadata = readMetadata(chat.metadata);
    const game_id = metadata.gameId;
    const game_time = metadata.gameTime ?? null;
    return {
      enabled: isFeatureEnabled(chat, metadata, this.package_id),
      game_id,
      game_time,
      subjects: await this.subjects(chat),
      effects
    };
  }
  async initialize(chat_id, subject) {
    return this.api.runtime.persistence.withChatLock(chat_id, async () => {
      const context = await this.enabledContext(chat_id);
      const subject_info = findSubject(context.subjects, subject);
      const document_id = anatomyDocumentId(context.game_id, subject);
      const current = await this.getDocument(document_id);
      if (current) return buildAnatomyBody(asStoredDocument(current).data, subject_info, context.game_time, effects);
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const data = {
        game_id: context.game_id,
        subject,
        template_id: dataset.template_id,
        anatomy: createAnatomyFromTemplate(dataset),
        capabilities: createCapabilityState()
      };
      const created = await this.api.runtime.persistence.documents.create({
        id: document_id,
        packageId: this.package_id,
        kind: DOCUMENT_KIND,
        name: `Anatomy ${context.game_id} ${subject.kind}:${subject.id}`,
        description: "Persistent modular anatomy state.",
        data,
        createdAt: now,
        updatedAt: now
      });
      return buildAnatomyBody(asStoredDocument(created).data, subject_info, context.game_time, effects);
    });
  }
  async read(chat_id, subject) {
    const context = await this.enabledContext(chat_id);
    const subject_info = findSubject(context.subjects, subject);
    const current = await this.getDocument(anatomyDocumentId(context.game_id, subject));
    if (!current) {
      return {
        state: "uninitialized",
        game_id: context.game_id,
        subject: subject_info,
        template_id: null,
        game_time: context.game_time,
        permanent: null,
        effective_parts: null,
        baseline_descriptions: null,
        effective_descriptions: null,
        effects,
        statuses: [],
        capabilities: null,
        baseline_capabilities: null,
        effective_capabilities: null,
        capability_demo_available: false
      };
    }
    return buildAnatomyBody(asStoredDocument(current).data, subject_info, context.game_time, effects);
  }
  async applyEffect(chat_id, subject, part_id, effect_id) {
    return this.api.runtime.persistence.withChatLock(chat_id, async () => {
      const context = await this.enabledContext(chat_id);
      const subject_info = findSubject(context.subjects, subject);
      const current = await this.requireDocument(context.game_id, subject);
      const definition = effects.find((effect) => effect.effect_id === effect_id);
      const status_id = definition.lifetime.kind === "temporary" ? randomUUID() : null;
      let anatomy;
      if (definition.lifetime.kind === "temporary") {
        const temporaryDefinition = definition;
        anatomy = applyAnatomyEffect(current.data.anatomy, temporaryDefinition, part_id, {
          kind: "temporary",
          now: requireGameTime(context.game_time),
          status_id
        });
      } else {
        const permanentDefinition = definition;
        anatomy = applyAnatomyEffect(current.data.anatomy, permanentDefinition, part_id);
      }
      const capabilities = settleBeforeAnatomyMutation(current.data.anatomy, current.data.capabilities, context.game_time);
      const updated = await this.save(current, { ...current.data, anatomy, capabilities });
      return {
        status_id,
        body: buildAnatomyBody(updated.data, subject_info, context.game_time, effects)
      };
    });
  }
  async removeStatus(chat_id, subject, status_id) {
    return this.api.runtime.persistence.withChatLock(chat_id, async () => {
      const context = await this.enabledContext(chat_id);
      const subject_info = findSubject(context.subjects, subject);
      const current = await this.requireDocument(context.game_id, subject);
      const capabilities = settleBeforeAnatomyMutation(current.data.anatomy, current.data.capabilities, context.game_time);
      const anatomy = removeStatus(current.data.anatomy, status_id);
      const updated = await this.save(current, { ...current.data, anatomy, capabilities });
      return {
        status_id,
        body: buildAnatomyBody(updated.data, subject_info, context.game_time, effects)
      };
    });
  }
  async installCapabilityDemo(chat_id, subject) {
    return this.api.runtime.persistence.withChatLock(chat_id, async () => {
      const context = await this.enabledContext(chat_id);
      const subject_info = findSubject(context.subjects, subject);
      const current = await this.requireDocument(context.game_id, subject);
      if (current.data.template_id !== capabilityDemo2.template_id) {
        throw new Error("Capability demo requires the humanoid-functional-basic template.");
      }
      if (current.data.capabilities.installed_bundle_ids.includes(capabilityDemo2.bundle_id)) {
        return buildAnatomyBody(current.data, subject_info, context.game_time, effects);
      }
      const capabilities = settleBeforeAnatomyMutation(current.data.anatomy, current.data.capabilities, context.game_time);
      const installed = installCapabilityBundle(current.data.anatomy, capabilities, capabilityDemo2);
      const updated = await this.save(current, {
        ...current.data,
        anatomy: installed.anatomy,
        capabilities: installed.capabilities
      });
      return buildAnatomyBody(updated.data, subject_info, context.game_time, effects);
    });
  }
  async advanceCapabilities(chat_id, subject) {
    return this.api.runtime.persistence.withChatLock(chat_id, async () => {
      const context = await this.enabledContext(chat_id);
      const subject_info = findSubject(context.subjects, subject);
      const current = await this.requireDocument(context.game_id, subject);
      const now = requireCapabilityTime(context.game_time);
      const capabilities = advanceCapabilities(current.data.anatomy, current.data.capabilities, now);
      if (capabilities === current.data.capabilities) {
        return buildAnatomyBody(current.data, subject_info, context.game_time, effects);
      }
      const updated = await this.save(current, { ...current.data, capabilities });
      return buildAnatomyBody(updated.data, subject_info, context.game_time, effects);
    });
  }
  async contributePrompt(request) {
    if (request.mode !== "game") return null;
    const context = await this.getContext(request.chatId);
    if (!context.enabled) return null;
    const blocks = [
      "Modular Anatomy (deterministic read-only context):",
      `Native game time: ${context.game_time ? formatGameTime(context.game_time) : "not initialized; effective values are not resolved."}`,
      `Named effects available for explicit invocation: ${context.effects.map((effect) => effect.effect_id).join(", ")}`
    ];
    for (const subject of context.subjects) {
      const current = await this.getDocument(anatomyDocumentId(context.game_id, subject));
      if (!current) continue;
      const stored = asStoredDocument(current);
      const body = buildAnatomyBody(stored.data, subject, context.game_time, effects);
      blocks.push(
        JSON.stringify({
          subject,
          template_id: body.template_id,
          values: context.game_time ? "effective" : "permanent baseline; not resolved against native time",
          parts: context.game_time ? body.effective_descriptions : body.baseline_descriptions,
          statuses: body.statuses,
          capabilities: body.capabilities,
          baseline_capabilities: body.baseline_capabilities,
          effective_capabilities: body.effective_capabilities
        })
      );
    }
    return blocks.join("\n");
  }
  async enabledContext(chat_id) {
    const context = await this.getContext(chat_id);
    if (!context.enabled) throw new Error("Modular Anatomy is unavailable until enabled in an active Game.");
    return context;
  }
  async requireChat(chat_id) {
    const chat = await this.api.runtime.persistence.getChat(chat_id);
    if (!chat) throw new Error(`Chat ${chat_id} was not found.`);
    return chat;
  }
  async subjects(chat) {
    const characters = await this.api.runtime.resources.listCharacters(chat.characterIds);
    const personas = chat.personaId ? await this.api.runtime.resources.listPersonas([chat.personaId]) : [];
    return [
      ...characters.map((character) => ({
        kind: "character",
        id: character.id,
        name: resourceName(character.data)
      })),
      ...personas.map((persona) => ({
        kind: "persona",
        id: persona.id,
        name: resourceName(persona.data)
      }))
    ];
  }
  async getDocument(id) {
    return this.api.runtime.persistence.documents.getById(this.package_id, id);
  }
  async requireDocument(game_id, subject) {
    const current = await this.getDocument(anatomyDocumentId(game_id, subject));
    if (!current) throw new Error("Initialize the anatomy before applying or removing a status.");
    return asStoredDocument(current);
  }
  async save(current, data) {
    const updated = await this.api.runtime.persistence.documents.update({
      id: current.id,
      packageId: this.package_id,
      expectedRevision: current.revision,
      name: current.name,
      description: current.description,
      data,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    if (!updated) throw new Error("Anatomy storage conflict; reload the body and try the action again.");
    return asStoredDocument(updated);
  }
};
function createAnatomyService(context) {
  return new AnatomyService(context.api, context.package.id);
}
function anatomyDocumentId(game_id, subject) {
  return `anatomy:${JSON.stringify([game_id, subject.kind, subject.id])}`;
}
function asStoredDocument(document) {
  const data = typeof document.data === "string" ? JSON.parse(document.data) : document.data;
  return { ...document, data };
}
function readMetadata(metadata) {
  return typeof metadata === "string" ? JSON.parse(metadata) : metadata;
}
function isFeatureEnabled(chat, metadata, package_id) {
  return chat.mode === "game" && metadata.enableAgents === true && metadata.activeAgentIds.includes(package_id);
}
function findSubject(subjects, subject) {
  return subjects.find((candidate) => candidate.kind === subject.kind && candidate.id === subject.id);
}
function resourceName(data) {
  const record = typeof data === "string" ? JSON.parse(data) : data;
  return record.name;
}
function requireGameTime(game_time) {
  if (!game_time) throw new Error("Initialize the native Game clock before applying a temporary anatomy effect.");
  return game_time;
}
function settleBeforeAnatomyMutation(anatomy, capabilities, game_time) {
  if (!capabilities.definitions.length) return capabilities;
  return advanceCapabilities(anatomy, capabilities, requireCapabilityTime(game_time));
}
function requireCapabilityTime(game_time) {
  if (!game_time) throw new Error("Initialize the native Game clock before advancing capabilities.");
  return game_time;
}
function formatGameTime(time) {
  return `day ${time.day}, ${String(time.hour).padStart(2, "0")}:${String(time.minute).padStart(2, "0")}`;
}

// src/marinara/server.ts
async function activate(context) {
  const service = createAnatomyService(context);
  const cleanups = [];
  for (const registration of toolRegistrations(service)) {
    cleanups.push(context.api.registerTool(registration));
  }
  cleanups.push(context.api.registerPromptContext((request) => service.contributePrompt(request)));
  cleanups.push(await context.api.registerPrivilegedRoutes((rawApp) => {
    const app = rawApp;
    app.get("/context", (request, reply) => route(reply, () => service.getContext(stringQuery(request, "chat_id"))));
    app.get("/body", (request, reply) => route(reply, () => service.read(
      stringQuery(request, "chat_id"),
      subjectFrom(request.query ?? {})
    )));
    app.post("/body/initialize", (request, reply) => route(reply, () => service.initialize(
      stringBody(request, "chat_id"),
      subjectFrom(request.body ?? {})
    )));
    app.post("/body/effects", (request, reply) => route(reply, () => service.applyEffect(
      stringBody(request, "chat_id"),
      subjectFrom(request.body ?? {}),
      stringBody(request, "part_id"),
      stringBody(request, "effect_id")
    )));
    app.post("/body/capabilities/install-demo", (request, reply) => route(reply, () => service.installCapabilityDemo(
      stringBody(request, "chat_id"),
      subjectFrom(request.body ?? {})
    )));
    app.post("/body/capabilities/advance", (request, reply) => route(reply, () => service.advanceCapabilities(
      stringBody(request, "chat_id"),
      subjectFrom(request.body ?? {})
    )));
    app.post("/body/statuses/remove", (request, reply) => route(reply, () => service.removeStatus(
      stringBody(request, "chat_id"),
      subjectFrom(request.body ?? {}),
      stringBody(request, "status_id")
    )));
  }, { prefix: `/api/${PACKAGE_ID}` }));
  return () => {
    for (const cleanup of cleanups.reverse()) cleanup();
  };
}
function toolRegistrations(service) {
  const subjectProperties = {
    subject_kind: { type: "string", enum: ["character", "persona"] },
    subject_id: { type: "string" }
  };
  return [
    {
      name: "initialize_body",
      description: "Initialize the selected character or persona with the authored modular anatomy template.",
      parameters: {
        type: "object",
        properties: subjectProperties,
        required: ["subject_kind", "subject_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.initialize(call.chatId, subjectFrom(args))
    },
    {
      name: "read_body",
      description: "Read the selected subject anatomy baseline and effective native-time projection.",
      parameters: {
        type: "object",
        properties: subjectProperties,
        required: ["subject_kind", "subject_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.read(call.chatId, subjectFrom(args))
    },
    {
      name: "apply_effect",
      description: "Apply one authored deterministic anatomy effect to a selected part after the game rules resolve it.",
      parameters: {
        type: "object",
        properties: {
          ...subjectProperties,
          part_id: { type: "string", enum: ["arm.left", "arm.right"] },
          effect_id: { type: "string", enum: ["temporary-arm-growth", "temporary-scales", "permanent-composition-shift"] }
        },
        required: ["subject_kind", "subject_id", "part_id", "effect_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.applyEffect(call.chatId, subjectFrom(args), stringArg(args, "part_id"), stringArg(args, "effect_id"))
    },
    {
      name: "install_capability_demo",
      description: "Add the fictional manipulator, producer, and reservoir demonstration capabilities without replacing existing anatomy.",
      parameters: {
        type: "object",
        properties: subjectProperties,
        required: ["subject_kind", "subject_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.installCapabilityDemo(call.chatId, subjectFrom(args))
    },
    {
      name: "advance_capabilities",
      description: "Settle installed capability production to the existing native game time without advancing the game clock.",
      parameters: {
        type: "object",
        properties: subjectProperties,
        required: ["subject_kind", "subject_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.advanceCapabilities(call.chatId, subjectFrom(args))
    },
    {
      name: "remove_status",
      description: "Remove one selected temporary anatomy status and reveal the current baseline or remaining statuses.",
      parameters: {
        type: "object",
        properties: {
          ...subjectProperties,
          status_id: { type: "string" }
        },
        required: ["subject_kind", "subject_id", "status_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.removeStatus(call.chatId, subjectFrom(args), stringArg(args, "status_id"))
    }
  ];
}
function subjectFrom(values) {
  return {
    kind: stringValue(values, "subject_kind"),
    id: stringValue(values, "subject_id")
  };
}
function stringQuery(request, key) {
  return stringValue(request.query ?? {}, key);
}
function stringBody(request, key) {
  return stringValue(request.body ?? {}, key);
}
function stringArg(args, key) {
  return stringValue(args, key);
}
function stringValue(values, key) {
  return values[key];
}
async function route(reply, action) {
  try {
    return await action();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const status = message.includes("storage conflict") ? 409 : message.includes("unavailable") ? 403 : 400;
    return reply.status(status).send({ error: message });
  }
}
export {
  activate
};
