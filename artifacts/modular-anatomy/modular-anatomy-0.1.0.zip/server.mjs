// src/marinara/service.ts
import { randomUUID } from "node:crypto";

// data/humanoid-basic.json
var humanoid_basic_default = {
  template_id: "humanoid-functional-basic",
  units: {
    length: "cm"
  },
  parts: [
    {
      part_id: "body",
      parent_id: null,
      name: "Body",
      description: "The full-body structural aggregate.",
      attributes: {
        geometry: { length: 180, width: 50, depth: 30, shape: "aggregate" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: []
      }
    },
    {
      part_id: "torso",
      parent_id: "body",
      name: "Torso",
      description: "The trunk between the neck and pelvis.",
      attributes: {
        geometry: { length: 60, width: 40, depth: 25, shape: "tapered_box" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: []
      }
    },
    {
      part_id: "arm.left",
      parent_id: "torso",
      name: "Left arm",
      description: "A composite upper limb including the hand.",
      attributes: {
        geometry: { length: 60, width: 10, depth: 10, shape: "tapered_cylinder" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: ["manipulation"]
      }
    },
    {
      part_id: "arm.right",
      parent_id: "torso",
      name: "Right arm",
      description: "A composite upper limb including the hand.",
      attributes: {
        geometry: { length: 60, width: 10, depth: 10, shape: "tapered_cylinder" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: ["manipulation"]
      }
    },
    {
      part_id: "leg.left",
      parent_id: "torso",
      name: "Left leg",
      description: "A composite lower limb including the foot.",
      attributes: {
        geometry: { length: 90, width: 15, depth: 15, shape: "tapered_cylinder" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: ["locomotion"]
      }
    },
    {
      part_id: "leg.right",
      parent_id: "torso",
      name: "Right leg",
      description: "A composite lower limb including the foot.",
      attributes: {
        geometry: { length: 90, width: 15, depth: 15, shape: "tapered_cylinder" },
        composition: { bone: 0.2, muscle: 0.55, fat: 0.15, other_soft_tissue: 0.1 },
        mechanics: { stiffness: 0.5 },
        surface: { coverings: ["skin"], color: "#c58c70", texture: "smooth", markings: [] },
        functions: ["locomotion"]
      }
    }
  ]
};

// data/anatomy-effects.json
var anatomy_effects_default = [
  {
    effect_id: "temporary-arm-growth",
    name: "Temporary arm growth",
    description: "Adds three centimetres to the selected arm for two native game hours.",
    eligible_part_ids: ["arm.left", "arm.right"],
    operations: [
      { field: "geometry.length", op: "add", value: 3 }
    ],
    lifetime: { kind: "temporary", duration_minutes: 120 }
  },
  {
    effect_id: "temporary-scales",
    name: "Temporary scales",
    description: "Adds a scale covering and changes stiffness for two native game hours.",
    eligible_part_ids: ["arm.left", "arm.right"],
    operations: [
      { field: "surface.coverings", op: "set", value: ["skin", "scales"] },
      { field: "mechanics.stiffness", op: "set", value: 0.8 }
    ],
    lifetime: { kind: "temporary", duration_minutes: 120 }
  },
  {
    effect_id: "permanent-composition-shift",
    name: "Permanent composition shift",
    description: "Sets the selected arm's authored muscle and fat proportions.",
    eligible_part_ids: ["arm.left", "arm.right"],
    operations: [
      { field: "composition.muscle", op: "set", value: 0.45 },
      { field: "composition.fat", op: "set", value: 0.25 }
    ],
    lifetime: { kind: "permanent" }
  }
];

// src/time.ts
function toGameMinutes(time) {
  return (time.day - 1) * 24 * 60 + time.hour * 60 + time.minute;
}

// src/anatomy.ts
function clone(value) {
  return structuredClone(value);
}
function applyNumeric(current, operation) {
  switch (operation.op) {
    case "set":
      return operation.value;
    case "add":
      return current + operation.value;
    case "subtract":
      return current - operation.value;
    case "multiply":
      return current * operation.value;
  }
}
function applyOperation(part, operation) {
  switch (operation.field) {
    case "geometry.length":
      part.attributes.geometry.length = applyNumeric(part.attributes.geometry.length, operation);
      return;
    case "geometry.width":
      part.attributes.geometry.width = applyNumeric(part.attributes.geometry.width, operation);
      return;
    case "geometry.depth":
      part.attributes.geometry.depth = applyNumeric(part.attributes.geometry.depth, operation);
      return;
    case "geometry.shape":
      part.attributes.geometry.shape = operation.value;
      return;
    case "composition":
      part.attributes.composition = clone(operation.value);
      return;
    case "mechanics.stiffness":
      part.attributes.mechanics.stiffness = applyNumeric(part.attributes.mechanics.stiffness, operation);
      return;
    case "surface.coverings":
      part.attributes.surface.coverings = [...operation.value];
      return;
    case "surface.color":
      part.attributes.surface.color = operation.value;
      return;
    case "surface.texture":
      part.attributes.surface.texture = operation.value;
      return;
    case "surface.markings":
      part.attributes.surface.markings = [...operation.value];
      return;
    case "functions":
      part.attributes.functions = [...operation.value];
      return;
    default: {
      const material = operation.field.slice("composition.".length);
      const composition = part.attributes.composition;
      composition[material] = applyNumeric(composition[material], operation);
    }
  }
}
function copyPart(part) {
  return clone(part);
}
function copyParts(parts) {
  return parts.map(copyPart);
}
function createAnatomy(parts) {
  return {
    parts: copyParts(parts),
    statuses: []
  };
}
function changePermanentPart(anatomy, part_id, operations) {
  const parts = copyParts(anatomy.parts);
  const target = parts.find((part) => part.part_id === part_id);
  for (const operation of operations) {
    applyOperation(target, operation);
  }
  return {
    parts,
    statuses: clone(anatomy.statuses)
  };
}
function applyStatus(anatomy, status) {
  return {
    parts: clone(anatomy.parts),
    statuses: [...clone(anatomy.statuses), clone(status)]
  };
}
function removeStatus(anatomy, status_id) {
  return {
    parts: clone(anatomy.parts),
    statuses: anatomy.statuses.filter((status) => status.status_id !== status_id).map(clone)
  };
}
function statusIsActive(status, now) {
  const current = toGameMinutes(now);
  const starts = toGameMinutes(status.starts_at);
  const expires = status.expires_at === null ? null : toGameMinutes(status.expires_at);
  return current >= starts && (expires === null || current < expires);
}
function resolveAnatomy(anatomy, now) {
  const parts = copyParts(anatomy.parts);
  for (const status of anatomy.statuses) {
    if (!statusIsActive(status, now)) {
      continue;
    }
    const target = parts.find((part) => part.part_id === status.part_id);
    for (const operation of status.operations) {
      applyOperation(target, operation);
    }
  }
  return parts;
}

// src/effects.ts
function applyAnatomyEffect(anatomy, definition, part_id, context) {
  if (definition.lifetime.kind === "permanent") {
    return changePermanentPart(anatomy, part_id, definition.operations);
  }
  const status = {
    status_id: context.status_id,
    part_id,
    starts_at: context.now,
    expires_at: addGameMinutes(context.now, definition.lifetime.duration_minutes),
    operations: definition.operations
  };
  return applyStatus(anatomy, status);
}
function addGameMinutes(now, duration_minutes) {
  const total = toGameMinutes(now) + duration_minutes;
  const day = Math.floor(total / 1440) + 1;
  const day_minutes = total % 1440;
  return {
    day,
    hour: Math.floor(day_minutes / 60),
    minute: day_minutes % 60
  };
}

// src/marinara/service.ts
var PACKAGE_ID = "modular-anatomy";
var DOCUMENT_KIND = "character-anatomy";
var dataset = humanoid_basic_default;
var effects = anatomy_effects_default;
var AnatomyService = class {
  api;
  package_id;
  constructor(api, package_id = PACKAGE_ID) {
    this.api = api;
    this.package_id = package_id;
  }
  async getContext(chat_id) {
    const chat = await this.requireChat(chat_id);
    const metadata = readMetadata(chat.metadata);
    const game_id = metadata.gameId;
    const game_time = metadata.gameTime ?? null;
    return {
      enabled: isFeatureEnabled(chat, metadata, this.package_id),
      game_id,
      game_time,
      subjects: await this.subjects(chat),
      effects
    };
  }
  async initialize(chat_id, subject) {
    return this.api.runtime.persistence.withChatLock(chat_id, async () => {
      const context = await this.enabledContext(chat_id);
      const subject_info = findSubject(context.subjects, subject);
      const document_id = anatomyDocumentId(context.game_id, subject);
      const current = await this.getDocument(document_id);
      if (current) return bodyFromDocument(asStoredDocument(current), subject_info, context.game_time, effects);
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const data = {
        game_id: context.game_id,
        subject,
        template_id: dataset.template_id,
        anatomy: createAnatomy(dataset.parts)
      };
      const created = await this.api.runtime.persistence.documents.create({
        id: document_id,
        packageId: this.package_id,
        kind: DOCUMENT_KIND,
        name: `Anatomy ${context.game_id} ${subject.kind}:${subject.id}`,
        description: "Persistent modular anatomy state.",
        data,
        createdAt: now,
        updatedAt: now
      });
      return bodyFromDocument(asStoredDocument(created), subject_info, context.game_time, effects);
    });
  }
  async read(chat_id, subject) {
    const context = await this.enabledContext(chat_id);
    const subject_info = findSubject(context.subjects, subject);
    const current = await this.getDocument(anatomyDocumentId(context.game_id, subject));
    if (!current) {
      return {
        state: "uninitialized",
        game_id: context.game_id,
        subject: subject_info,
        template_id: null,
        game_time: context.game_time,
        permanent: null,
        effective_parts: null,
        effects,
        statuses: []
      };
    }
    return bodyFromDocument(asStoredDocument(current), subject_info, context.game_time, effects);
  }
  async applyEffect(chat_id, subject, part_id, effect_id) {
    return this.api.runtime.persistence.withChatLock(chat_id, async () => {
      const context = await this.enabledContext(chat_id);
      const subject_info = findSubject(context.subjects, subject);
      const current = await this.requireDocument(context.game_id, subject);
      const definition = effects.find((effect) => effect.effect_id === effect_id);
      const status_id = definition.lifetime.kind === "temporary" ? randomUUID() : null;
      let anatomy;
      if (definition.lifetime.kind === "temporary") {
        const temporaryDefinition = definition;
        anatomy = applyAnatomyEffect(current.data.anatomy, temporaryDefinition, part_id, {
          kind: "temporary",
          now: requireGameTime(context.game_time),
          status_id
        });
      } else {
        const permanentDefinition = definition;
        anatomy = applyAnatomyEffect(current.data.anatomy, permanentDefinition, part_id);
      }
      const updated = await this.save(current, { ...current.data, anatomy });
      return {
        status_id,
        body: bodyFromDocument(updated, subject_info, context.game_time, effects)
      };
    });
  }
  async removeStatus(chat_id, subject, status_id) {
    return this.api.runtime.persistence.withChatLock(chat_id, async () => {
      const context = await this.enabledContext(chat_id);
      const subject_info = findSubject(context.subjects, subject);
      const current = await this.requireDocument(context.game_id, subject);
      const anatomy = removeStatus(current.data.anatomy, status_id);
      const updated = await this.save(current, { ...current.data, anatomy });
      return {
        status_id,
        body: bodyFromDocument(updated, subject_info, context.game_time, effects)
      };
    });
  }
  async contributePrompt(request) {
    if (request.mode !== "game") return null;
    const context = await this.getContext(request.chatId);
    if (!context.enabled) return null;
    const blocks = [
      "Modular Anatomy (deterministic read-only context):",
      `Native game time: ${context.game_time ? formatGameTime(context.game_time) : "not initialized; effective values are not resolved."}`,
      `Named effects available for explicit invocation: ${context.effects.map((effect) => effect.effect_id).join(", ")}`
    ];
    for (const subject of context.subjects) {
      const current = await this.getDocument(anatomyDocumentId(context.game_id, subject));
      if (!current) continue;
      const stored = asStoredDocument(current);
      const anatomy = stored.data.anatomy;
      const parts = context.game_time ? resolveAnatomy(anatomy, context.game_time) : anatomy.parts;
      blocks.push(
        JSON.stringify({
          subject,
          template_id: stored.data.template_id,
          values: context.game_time ? "effective" : "permanent baseline; not resolved against native time",
          parts,
          statuses: anatomy.statuses
        })
      );
    }
    return blocks.join("\n");
  }
  async enabledContext(chat_id) {
    const context = await this.getContext(chat_id);
    if (!context.enabled) throw new Error("Modular Anatomy is unavailable until enabled in an active Game.");
    return context;
  }
  async requireChat(chat_id) {
    const chat = await this.api.runtime.persistence.getChat(chat_id);
    if (!chat) throw new Error(`Chat ${chat_id} was not found.`);
    return chat;
  }
  async subjects(chat) {
    const characters = await this.api.runtime.resources.listCharacters(chat.characterIds);
    const personas = chat.personaId ? await this.api.runtime.resources.listPersonas([chat.personaId]) : [];
    return [
      ...characters.map((character) => ({
        kind: "character",
        id: character.id,
        name: resourceName(character.data)
      })),
      ...personas.map((persona) => ({
        kind: "persona",
        id: persona.id,
        name: resourceName(persona.data)
      }))
    ];
  }
  async getDocument(id) {
    return this.api.runtime.persistence.documents.getById(this.package_id, id);
  }
  async requireDocument(game_id, subject) {
    const current = await this.getDocument(anatomyDocumentId(game_id, subject));
    if (!current) throw new Error("Initialize the anatomy before applying or removing a status.");
    return asStoredDocument(current);
  }
  async save(current, data) {
    const updated = await this.api.runtime.persistence.documents.update({
      id: current.id,
      packageId: this.package_id,
      expectedRevision: current.revision,
      name: current.name,
      description: current.description,
      data,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    if (!updated) throw new Error("Anatomy storage conflict; reload the body and try the action again.");
    return asStoredDocument(updated);
  }
};
function createAnatomyService(context) {
  return new AnatomyService(context.api, context.package.id);
}
function anatomyDocumentId(game_id, subject) {
  return `anatomy:${JSON.stringify([game_id, subject.kind, subject.id])}`;
}
function asStoredDocument(document) {
  const data = typeof document.data === "string" ? JSON.parse(document.data) : document.data;
  return { ...document, data };
}
function bodyFromDocument(document, subject, game_time, available_effects) {
  return {
    state: game_time ? "ready" : "clock_uninitialized",
    game_id: document.data.game_id,
    subject,
    template_id: document.data.template_id,
    game_time,
    permanent: document.data.anatomy,
    effective_parts: game_time ? resolveAnatomy(document.data.anatomy, game_time) : null,
    effects: available_effects,
    statuses: document.data.anatomy.statuses
  };
}
function readMetadata(metadata) {
  return typeof metadata === "string" ? JSON.parse(metadata) : metadata;
}
function isFeatureEnabled(chat, metadata, package_id) {
  return chat.mode === "game" && metadata.enableAgents === true && metadata.activeAgentIds.includes(package_id);
}
function findSubject(subjects, subject) {
  return subjects.find((candidate) => candidate.kind === subject.kind && candidate.id === subject.id);
}
function resourceName(data) {
  const record = typeof data === "string" ? JSON.parse(data) : data;
  return record.name;
}
function requireGameTime(game_time) {
  if (!game_time) throw new Error("Initialize the native Game clock before applying a temporary anatomy effect.");
  return game_time;
}
function formatGameTime(time) {
  return `day ${time.day}, ${String(time.hour).padStart(2, "0")}:${String(time.minute).padStart(2, "0")}`;
}

// src/marinara/server.ts
async function activate(context) {
  const service = createAnatomyService(context);
  const cleanups = [];
  for (const registration of toolRegistrations(service)) {
    cleanups.push(context.api.registerTool(registration));
  }
  cleanups.push(context.api.registerPromptContext((request) => service.contributePrompt(request)));
  cleanups.push(await context.api.registerPrivilegedRoutes((rawApp) => {
    const app = rawApp;
    app.get("/context", (request, reply) => route(reply, () => service.getContext(stringQuery(request, "chat_id"))));
    app.get("/body", (request, reply) => route(reply, () => service.read(
      stringQuery(request, "chat_id"),
      subjectFrom(request.query ?? {})
    )));
    app.post("/body/initialize", (request, reply) => route(reply, () => service.initialize(
      stringBody(request, "chat_id"),
      subjectFrom(request.body ?? {})
    )));
    app.post("/body/effects", (request, reply) => route(reply, () => service.applyEffect(
      stringBody(request, "chat_id"),
      subjectFrom(request.body ?? {}),
      stringBody(request, "part_id"),
      stringBody(request, "effect_id")
    )));
    app.post("/body/statuses/remove", (request, reply) => route(reply, () => service.removeStatus(
      stringBody(request, "chat_id"),
      subjectFrom(request.body ?? {}),
      stringBody(request, "status_id")
    )));
  }, { prefix: `/api/${PACKAGE_ID}` }));
  return () => {
    for (const cleanup of cleanups.reverse()) cleanup();
  };
}
function toolRegistrations(service) {
  const subjectProperties = {
    subject_kind: { type: "string", enum: ["character", "persona"] },
    subject_id: { type: "string" }
  };
  return [
    {
      name: "initialize_body",
      description: "Initialize the selected character or persona with the authored modular anatomy template.",
      parameters: {
        type: "object",
        properties: subjectProperties,
        required: ["subject_kind", "subject_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.initialize(call.chatId, subjectFrom(args))
    },
    {
      name: "read_body",
      description: "Read the selected subject anatomy baseline and effective native-time projection.",
      parameters: {
        type: "object",
        properties: subjectProperties,
        required: ["subject_kind", "subject_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.read(call.chatId, subjectFrom(args))
    },
    {
      name: "apply_effect",
      description: "Apply one authored deterministic anatomy effect to a selected part after the game rules resolve it.",
      parameters: {
        type: "object",
        properties: {
          ...subjectProperties,
          part_id: { type: "string", enum: ["arm.left", "arm.right"] },
          effect_id: { type: "string", enum: ["temporary-arm-growth", "temporary-scales", "permanent-composition-shift"] }
        },
        required: ["subject_kind", "subject_id", "part_id", "effect_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.applyEffect(call.chatId, subjectFrom(args), stringArg(args, "part_id"), stringArg(args, "effect_id"))
    },
    {
      name: "remove_status",
      description: "Remove one selected temporary anatomy status and reveal the current baseline or remaining statuses.",
      parameters: {
        type: "object",
        properties: {
          ...subjectProperties,
          status_id: { type: "string" }
        },
        required: ["subject_kind", "subject_id", "status_id"],
        additionalProperties: false
      },
      handler: (args, call) => service.removeStatus(call.chatId, subjectFrom(args), stringArg(args, "status_id"))
    }
  ];
}
function subjectFrom(values) {
  return {
    kind: stringValue(values, "subject_kind"),
    id: stringValue(values, "subject_id")
  };
}
function stringQuery(request, key) {
  return stringValue(request.query ?? {}, key);
}
function stringBody(request, key) {
  return stringValue(request.body ?? {}, key);
}
function stringArg(args, key) {
  return stringValue(args, key);
}
function stringValue(values, key) {
  return values[key];
}
async function route(reply, action) {
  try {
    return await action();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const status = message.includes("storage conflict") ? 409 : message.includes("unavailable") ? 403 : 400;
    return reply.status(status).send({ error: message });
  }
}
export {
  activate
};
