"use strict";
(() => {
  // src/marinara/body-parts-view.ts
  function partsTable(body) {
    const section = document.createElement("section");
    section.append(heading("Body parts"));
    const parts = body.permanent?.parts ?? [];
    const parentNames = new Map(parts.map((part) => [part.part_id, part.name]));
    const index = document.createElement("ul");
    index.className = "part-index";
    for (const part of parts) {
      const parent = part.parent_id ? ` \xB7 parent: ${parentNames.get(part.parent_id) ?? part.parent_id}` : " \xB7 root";
      const item = document.createElement("li");
      item.textContent = `${part.name} (${part.part_id})${parent}`;
      index.append(item);
    }
    section.append(index);
    const effective = new Map((body.effective_parts ?? []).map((part) => [part.part_id, part]));
    for (const baseline of parts) {
      const current = effective.get(baseline.part_id);
      const article = document.createElement("article");
      article.className = "part-card";
      article.append(heading(`${baseline.name} (${baseline.part_id})`));
      article.append(text(baseline.description));
      if (baseline.parent_id) article.append(message(`Attached to: ${parentNames.get(baseline.parent_id) ?? baseline.parent_id}`));
      article.append(attributeGroup("Geometry", [
        ["Length", `${formatNumber(baseline.attributes.geometry.length)} cm`, current ? `${formatNumber(current.attributes.geometry.length)} cm` : null],
        ["Width", `${formatNumber(baseline.attributes.geometry.width)} cm`, current ? `${formatNumber(current.attributes.geometry.width)} cm` : null],
        ["Depth", `${formatNumber(baseline.attributes.geometry.depth)} cm`, current ? `${formatNumber(current.attributes.geometry.depth)} cm` : null],
        ["Shape", baseline.attributes.geometry.shape, current?.attributes.geometry.shape ?? null]
      ]));
      article.append(attributeGroup("Composition", compositionRows(baseline.attributes.composition, current?.attributes.composition)));
      article.append(attributeGroup("Surface and mechanics", [
        ["Stiffness", formatPercent(baseline.attributes.mechanics.stiffness), current ? formatPercent(current.attributes.mechanics.stiffness) : null],
        ["Coverings", baseline.attributes.surface.coverings.join(", ") || "none", current ? current.attributes.surface.coverings.join(", ") || "none" : null],
        ["Color", baseline.attributes.surface.color, current?.attributes.surface.color ?? null],
        ["Texture", baseline.attributes.surface.texture, current?.attributes.surface.texture ?? null],
        ["Markings", baseline.attributes.surface.markings.join(", ") || "none", current ? current.attributes.surface.markings.join(", ") || "none" : null]
      ]));
      article.append(attributeGroup("Roles", [
        ["Roles", formatList(baseline.roles), current ? formatList(current.roles) : null]
      ]));
      article.append(attributeGroup("Functions", [
        ["Functions", formatList(baseline.attributes.functions), current ? formatList(current.attributes.functions) : null]
      ]));
      section.append(article);
    }
    return section;
  }
  function attributeGroup(title, rows) {
    const group = document.createElement("div");
    group.className = "attribute-group";
    group.append(heading(title));
    for (const [label, baseline, effective] of rows) {
      const row = document.createElement("div");
      row.className = "attribute-row";
      row.append(text(label));
      const values = document.createElement("div");
      values.className = "attribute-values";
      values.append(text(`Baseline: ${baseline}`));
      values.append(text(effective === null ? "Effective: not resolved" : `Effective: ${effective}`));
      row.append(values);
      group.append(row);
    }
    return group;
  }
  function compositionRows(baseline, effective) {
    const keys = [.../* @__PURE__ */ new Set([...Object.keys(baseline), ...Object.keys(effective ?? {})])].sort();
    return keys.map((key) => [humanize(key), formatPercent(baseline[key] ?? 0), effective ? formatPercent(effective[key] ?? 0) : null]);
  }
  function formatList(values) {
    return values.map(humanize).join(", ") || "none";
  }
  function formatNumber(value) {
    return Number.isInteger(value) ? String(value) : value.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");
  }
  function formatPercent(value) {
    return `${formatNumber(value * 100)}%`;
  }
  function humanize(value) {
    return value.replaceAll("_", " ").replace(/\b\w/g, (character) => character.toUpperCase());
  }
  function heading(value) {
    const element = document.createElement("h3");
    element.textContent = value;
    return element;
  }
  function message(value) {
    return text(value);
  }
  function text(value) {
    const element = document.createElement("p");
    element.textContent = value;
    return element;
  }

  // src/marinara/client.ts
  var ModularAnatomyElement = class extends HTMLElement {
    props = null;
    context = null;
    body = null;
    subject = null;
    requestGeneration = 0;
    connected = false;
    set capabilityProps(value) {
      const previousChatId = this.props?.chatId;
      this.props = value;
      if (this.connected && previousChatId !== value.chatId) void this.refresh();
      else if (this.connected) this.render();
    }
    get capabilityProps() {
      return this.props;
    }
    connectedCallback() {
      this.connected = true;
      this.addEventListener("marinara-capability-props", this.handlePropsEvent);
      this.render();
      if (this.props?.chatId) void this.refresh();
    }
    disconnectedCallback() {
      this.connected = false;
      this.removeEventListener("marinara-capability-props", this.handlePropsEvent);
    }
    handlePropsEvent = () => {
      if (this.props?.chatId) void this.refresh();
    };
    async refresh() {
      const chatId = this.props?.chatId;
      if (!chatId) {
        this.context = null;
        this.body = null;
        this.render();
        return;
      }
      const generation = ++this.requestGeneration;
      try {
        const context = await requestJson(`/api/modular-anatomy/context?chat_id=${encodeURIComponent(chatId)}`);
        if (generation !== this.requestGeneration) return;
        this.context = context;
        this.subject = context.subjects.find((candidate) => candidate === this.subject || candidate.kind === this.subject?.kind && candidate.id === this.subject?.id) ?? context.subjects[0] ?? null;
        this.body = this.subject && context.enabled ? await requestJson(bodyUrl(chatId, this.subject)) : null;
        if (generation !== this.requestGeneration) return;
        this.render();
      } catch (error) {
        if (generation !== this.requestGeneration) return;
        this.body = null;
        this.renderError(error instanceof Error ? error.message : String(error));
      }
    }
    async initialize() {
      if (!this.props?.chatId || !this.subject) return;
      await this.mutate("/body/initialize", { subject_kind: this.subject.kind, subject_id: this.subject.id });
    }
    async applyEffect(part_id, effect_id) {
      if (!this.props?.chatId || !this.subject) return;
      await this.mutate("/body/effects", {
        subject_kind: this.subject.kind,
        subject_id: this.subject.id,
        part_id,
        effect_id
      });
    }
    async removeStatus(status_id) {
      if (!this.props?.chatId || !this.subject) return;
      await this.mutate("/body/statuses/remove", {
        subject_kind: this.subject.kind,
        subject_id: this.subject.id,
        status_id
      });
    }
    async mutate(path, body) {
      try {
        await requestJson(`/api/modular-anatomy${path}`, {
          method: "POST",
          body: JSON.stringify({ chat_id: this.props?.chatId, ...body }),
          headers: { "content-type": "application/json" }
        });
        await this.refresh();
      } catch (error) {
        this.renderError(error instanceof Error ? error.message : String(error));
      }
    }
    render() {
      const root = document.createElement("div");
      root.className = "modular-anatomy";
      root.append(styleNode());
      const header = document.createElement("div");
      header.className = "header";
      const title = document.createElement("h2");
      title.textContent = "Modular Anatomy";
      header.append(title);
      if (this.props?.onClose) {
        const back = document.createElement("button");
        back.type = "button";
        back.textContent = "Back to Agents";
        back.addEventListener("click", () => this.props?.onClose?.());
        header.append(back);
      }
      root.append(header);
      if (!this.props?.chatId) {
        root.append(message2("Open this detail panel from an active Game."));
        this.replaceChildren(root);
        return;
      }
      const controls = document.createElement("div");
      controls.className = "controls";
      const enabled = this.props.enabledForChat === true;
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.textContent = enabled ? "Disable for this Game" : "Enable for this Game";
      toggle.addEventListener("click", () => this.props?.onEnabledForChatChange?.(!enabled));
      controls.append(toggle);
      const refresh = document.createElement("button");
      refresh.type = "button";
      refresh.textContent = "Refresh";
      refresh.addEventListener("click", () => void this.refresh());
      controls.append(refresh);
      root.append(controls);
      if (!this.context) {
        root.append(message2("Loading native Game context\u2026"));
        this.replaceChildren(root);
        return;
      }
      root.append(message2(this.context.game_time ? `Native time: day ${this.context.game_time.day}, ${String(this.context.game_time.hour).padStart(2, "0")}:${String(this.context.game_time.minute).padStart(2, "0")}` : "Native numeric game time is not initialized. Use Marinara\u2019s existing Game time control before applying temporary effects."));
      if (!this.context.enabled) {
        root.append(message2("Enable Modular Anatomy for this Game to read or change anatomy."));
        this.replaceChildren(root);
        return;
      }
      if (!this.context.subjects.length) {
        root.append(message2("This Game has no character or persona subject available."));
        this.replaceChildren(root);
        return;
      }
      const subjectLabel = document.createElement("label");
      subjectLabel.textContent = "Subject";
      const subjectSelect = document.createElement("select");
      for (const candidate of this.context.subjects) {
        const option = document.createElement("option");
        option.value = `${candidate.kind}:${candidate.id}`;
        option.textContent = `${candidate.name} (${candidate.kind})`;
        option.selected = candidate.kind === this.subject?.kind && candidate.id === this.subject?.id;
        subjectSelect.append(option);
      }
      subjectSelect.addEventListener("change", () => {
        const selected = this.context?.subjects.find((candidate) => `${candidate.kind}:${candidate.id}` === subjectSelect.value);
        if (selected) {
          this.subject = selected;
          void this.refresh();
        }
      });
      subjectLabel.append(subjectSelect);
      root.append(subjectLabel);
      if (!this.body || this.body.state === "uninitialized") {
        const initialize = document.createElement("button");
        initialize.type = "button";
        initialize.textContent = "Initialize authored body template";
        initialize.addEventListener("click", () => void this.initialize());
        root.append(initialize);
        this.replaceChildren(root);
        return;
      }
      root.append(message2(`Template: ${this.body.template_id ?? "not initialized"}`));
      if (this.body.state === "clock_uninitialized") root.append(message2("Baseline is available; effective temporary values are not resolved until native numeric time exists."));
      root.append(effectControls(this.body, (part_id, effect_id) => void this.applyEffect(part_id, effect_id)));
      root.append(statusControls(this.body.statuses, this.body.game_time, (status_id) => void this.removeStatus(status_id)));
      root.append(partsTable(this.body));
      this.replaceChildren(root);
    }
    renderError(error) {
      const root = document.createElement("div");
      root.append(styleNode());
      root.append(message2(`Modular Anatomy error: ${error}`));
      const retry = document.createElement("button");
      retry.type = "button";
      retry.textContent = "Retry";
      retry.addEventListener("click", () => void this.refresh());
      root.append(retry);
      this.replaceChildren(root);
    }
  };
  function effectControls(body, apply) {
    const section = document.createElement("section");
    section.append(heading2("Apply authored effect"));
    const part = select("Part", body.effects[0]?.eligible_part_ids ?? []);
    const effect = document.createElement("select");
    effect.setAttribute("aria-label", "Effect");
    for (const definition of body.effects) {
      const option = document.createElement("option");
      option.value = definition.effect_id;
      option.textContent = `${definition.name}: ${definition.description}`;
      effect.append(option);
    }
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "Apply";
    button.addEventListener("click", () => apply(part.value, effect.value));
    section.append(part, effect, button);
    return section;
  }
  function statusControls(statuses, gameTime, remove) {
    const section = document.createElement("section");
    section.append(heading2("Temporary statuses"));
    if (!statuses.length) section.append(message2("None stored."));
    for (const status of statuses) {
      const expiry = status.expires_at ? ` until ${formatGameTime(status.expires_at)}` : " with no expiry";
      const expired = gameTime !== null && status.expires_at !== null && compareGameTime(gameTime, status.expires_at) >= 0;
      const state = status.expires_at === null ? "Active" : expired ? "Expired" : "Active";
      const row = document.createElement("div");
      row.className = `status ${expired ? "expired" : "active"}`;
      row.append(text2(`${state} \xB7 ${status.part_id} \xB7 starts ${formatGameTime(status.starts_at)}${expiry}`));
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "Remove";
      button.addEventListener("click", () => remove(status.status_id));
      row.append(button);
      section.append(row);
    }
    return section;
  }
  function formatGameTime(time) {
    return `day ${time.day}, ${String(time.hour).padStart(2, "0")}:${String(time.minute).padStart(2, "0")}`;
  }
  function compareGameTime(left, right) {
    return (left.day - right.day) * 1440 + (left.hour - right.hour) * 60 + left.minute - right.minute;
  }
  function select(label, values) {
    const element = document.createElement("select");
    element.setAttribute("aria-label", label);
    for (const value of values) {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      element.append(option);
    }
    return element;
  }
  function heading2(value) {
    const element = document.createElement("h3");
    element.textContent = value;
    return element;
  }
  function message2(value) {
    return text2(value);
  }
  function text2(value) {
    const element = document.createElement("p");
    element.textContent = value;
    return element;
  }
  function styleNode() {
    const style = document.createElement("style");
    style.textContent = `
    .modular-anatomy { box-sizing: border-box; color: inherit; display: grid; gap: 0.75rem; font: inherit; max-height: 100%; overflow-y: auto; padding: 1rem; }
    .modular-anatomy .header { align-items: center; display: flex; gap: 0.75rem; justify-content: space-between; }
    .modular-anatomy .controls, .modular-anatomy section, .modular-anatomy article, .modular-anatomy .attribute-group { display: grid; gap: 0.5rem; }
    .modular-anatomy .part-card { border: 1px solid var(--border); border-radius: 0.5rem; padding: 0.75rem; }
    .modular-anatomy .attribute-row { display: grid; gap: 0.25rem; grid-template-columns: minmax(7rem, 0.35fr) minmax(0, 1fr); }
    .modular-anatomy .attribute-row > p { margin: 0; font-weight: 600; }
    .modular-anatomy .attribute-values { display: grid; gap: 0.15rem; }
    .modular-anatomy .attribute-values p { margin: 0; }
    .modular-anatomy button, .modular-anatomy select { color: inherit; background: var(--surface); border: 1px solid var(--border); border-radius: 0.35rem; padding: 0.4rem; }
    .modular-anatomy pre { overflow: auto; color: inherit; opacity: 0.9; white-space: pre-wrap; }
    .modular-anatomy .part-index { margin: 0; padding-left: 1.25rem; }
    .modular-anatomy .status { align-items: center; display: flex; gap: 0.5rem; justify-content: space-between; }
    .modular-anatomy .status.expired { opacity: 0.7; }
  `;
    return style;
  }
  function bodyUrl(chatId, subject) {
    return `/api/modular-anatomy/body?chat_id=${encodeURIComponent(chatId)}&subject_kind=${encodeURIComponent(subject.kind)}&subject_id=${encodeURIComponent(subject.id)}`;
  }
  async function requestJson(url, init = {}) {
    const headers = new Headers(init.headers);
    if (init.method && init.method !== "GET") headers.set("x-marinara-csrf", "1");
    const adminSecret = localStorage.getItem("marinara_admin_secret");
    if (adminSecret) headers.set("X-Admin-Secret", adminSecret);
    const response = await fetch(url, { ...init, headers, credentials: "same-origin", cache: "no-store" });
    const payload = await response.json();
    if (!response.ok) {
      const errorPayload = payload;
      throw new Error(errorPayload.error ?? `Request failed with HTTP ${response.status}`);
    }
    return payload;
  }
  if (!customElements.get("marinara-capability-modular-anatomy")) {
    customElements.define("marinara-capability-modular-anatomy", ModularAnatomyElement);
  }
})();
