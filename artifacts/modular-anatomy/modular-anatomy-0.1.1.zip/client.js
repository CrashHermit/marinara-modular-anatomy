"use strict";
(() => {
  // src/marinara/client.ts
  var ModularAnatomyElement = class extends HTMLElement {
    props = null;
    context = null;
    body = null;
    subject = null;
    requestGeneration = 0;
    connected = false;
    set capabilityProps(value) {
      const previousChatId = this.props?.chatId;
      this.props = value;
      if (this.connected && previousChatId !== value.chatId) void this.refresh();
      else if (this.connected) this.render();
    }
    get capabilityProps() {
      return this.props;
    }
    connectedCallback() {
      this.connected = true;
      this.addEventListener("marinara-capability-props", this.handlePropsEvent);
      this.render();
      if (this.props?.chatId) void this.refresh();
    }
    disconnectedCallback() {
      this.connected = false;
      this.removeEventListener("marinara-capability-props", this.handlePropsEvent);
    }
    handlePropsEvent = () => {
      if (this.props?.chatId) void this.refresh();
    };
    async refresh() {
      const chatId = this.props?.chatId;
      if (!chatId) {
        this.context = null;
        this.body = null;
        this.render();
        return;
      }
      const generation = ++this.requestGeneration;
      try {
        const context = await requestJson(`/api/modular-anatomy/context?chat_id=${encodeURIComponent(chatId)}`);
        if (generation !== this.requestGeneration) return;
        this.context = context;
        this.subject = context.subjects.find((candidate) => candidate === this.subject || candidate.kind === this.subject?.kind && candidate.id === this.subject?.id) ?? context.subjects[0] ?? null;
        this.body = this.subject && context.enabled ? await requestJson(bodyUrl(chatId, this.subject)) : null;
        if (generation !== this.requestGeneration) return;
        this.render();
      } catch (error) {
        if (generation !== this.requestGeneration) return;
        this.body = null;
        this.renderError(error instanceof Error ? error.message : String(error));
      }
    }
    async initialize() {
      if (!this.props?.chatId || !this.subject) return;
      await this.mutate("/body/initialize", { subject_kind: this.subject.kind, subject_id: this.subject.id });
    }
    async applyEffect(part_id, effect_id) {
      if (!this.props?.chatId || !this.subject) return;
      await this.mutate("/body/effects", {
        subject_kind: this.subject.kind,
        subject_id: this.subject.id,
        part_id,
        effect_id
      });
    }
    async removeStatus(status_id) {
      if (!this.props?.chatId || !this.subject) return;
      await this.mutate("/body/statuses/remove", {
        subject_kind: this.subject.kind,
        subject_id: this.subject.id,
        status_id
      });
    }
    async mutate(path, body) {
      try {
        await requestJson(`/api/modular-anatomy${path}`, {
          method: "POST",
          body: JSON.stringify({ chat_id: this.props?.chatId, ...body }),
          headers: { "content-type": "application/json" }
        });
        await this.refresh();
      } catch (error) {
        this.renderError(error instanceof Error ? error.message : String(error));
      }
    }
    render() {
      const root = document.createElement("div");
      root.className = "modular-anatomy";
      root.append(styleNode());
      const title = document.createElement("h2");
      title.textContent = "Modular Anatomy";
      root.append(title);
      if (!this.props?.chatId) {
        root.append(message("Open this detail panel from an active Game."));
        this.replaceChildren(root);
        return;
      }
      const controls = document.createElement("div");
      controls.className = "controls";
      const enabled = this.props.enabledForChat === true;
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.textContent = enabled ? "Disable for this Game" : "Enable for this Game";
      toggle.addEventListener("click", () => this.props?.onEnabledForChatChange?.(!enabled));
      controls.append(toggle);
      const refresh = document.createElement("button");
      refresh.type = "button";
      refresh.textContent = "Refresh";
      refresh.addEventListener("click", () => void this.refresh());
      controls.append(refresh);
      root.append(controls);
      if (!this.context) {
        root.append(message("Loading native Game context\u2026"));
        this.replaceChildren(root);
        return;
      }
      root.append(message(this.context.game_time ? `Native time: day ${this.context.game_time.day}, ${String(this.context.game_time.hour).padStart(2, "0")}:${String(this.context.game_time.minute).padStart(2, "0")}` : "Native numeric game time is not initialized. Use Marinara\u2019s existing Game time control before applying temporary effects."));
      if (!this.context.enabled) {
        root.append(message("Enable Modular Anatomy for this Game to read or change anatomy."));
        this.replaceChildren(root);
        return;
      }
      if (!this.context.subjects.length) {
        root.append(message("This Game has no character or persona subject available."));
        this.replaceChildren(root);
        return;
      }
      const subjectLabel = document.createElement("label");
      subjectLabel.textContent = "Subject";
      const subjectSelect = document.createElement("select");
      for (const candidate of this.context.subjects) {
        const option = document.createElement("option");
        option.value = `${candidate.kind}:${candidate.id}`;
        option.textContent = `${candidate.name} (${candidate.kind})`;
        option.selected = candidate.kind === this.subject?.kind && candidate.id === this.subject?.id;
        subjectSelect.append(option);
      }
      subjectSelect.addEventListener("change", () => {
        const selected = this.context?.subjects.find((candidate) => `${candidate.kind}:${candidate.id}` === subjectSelect.value);
        if (selected) {
          this.subject = selected;
          void this.refresh();
        }
      });
      subjectLabel.append(subjectSelect);
      root.append(subjectLabel);
      if (!this.body || this.body.state === "uninitialized") {
        const initialize = document.createElement("button");
        initialize.type = "button";
        initialize.textContent = "Initialize authored body template";
        initialize.addEventListener("click", () => void this.initialize());
        root.append(initialize);
        this.replaceChildren(root);
        return;
      }
      root.append(message(`Template: ${this.body.template_id ?? "not initialized"}`));
      if (this.body.state === "clock_uninitialized") root.append(message("Baseline is available; effective temporary values are not resolved until native numeric time exists."));
      root.append(effectControls(this.body, (part_id, effect_id) => void this.applyEffect(part_id, effect_id)));
      root.append(statusControls(this.body.statuses, (status_id) => void this.removeStatus(status_id)));
      root.append(partsTable(this.body));
      this.replaceChildren(root);
    }
    renderError(error) {
      const root = document.createElement("div");
      root.append(styleNode());
      root.append(message(`Modular Anatomy error: ${error}`));
      const retry = document.createElement("button");
      retry.type = "button";
      retry.textContent = "Retry";
      retry.addEventListener("click", () => void this.refresh());
      root.append(retry);
      this.replaceChildren(root);
    }
  };
  function effectControls(body, apply) {
    const section = document.createElement("section");
    section.append(heading("Apply authored effect"));
    const part = select("Part", body.effects[0]?.eligible_part_ids ?? []);
    const effect = document.createElement("select");
    effect.setAttribute("aria-label", "Effect");
    for (const definition of body.effects) {
      const option = document.createElement("option");
      option.value = definition.effect_id;
      option.textContent = `${definition.name}: ${definition.description}`;
      effect.append(option);
    }
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "Apply";
    button.addEventListener("click", () => apply(part.value, effect.value));
    section.append(part, effect, button);
    return section;
  }
  function statusControls(statuses, remove) {
    const section = document.createElement("section");
    section.append(heading("Temporary statuses"));
    if (!statuses.length) section.append(message("None stored."));
    for (const status of statuses) {
      const row = document.createElement("div");
      row.className = "status";
      row.append(text(`${status.status_id} \xB7 ${status.part_id}`));
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "Remove";
      button.addEventListener("click", () => remove(status.status_id));
      row.append(button);
      section.append(row);
    }
    return section;
  }
  function partsTable(body) {
    const section = document.createElement("section");
    section.append(heading("Body parts"));
    const effective = new Map((body.effective_parts ?? []).map((part) => [part.part_id, part]));
    for (const baseline of body.permanent?.parts ?? []) {
      const article = document.createElement("article");
      article.append(heading(`${baseline.name} (${baseline.part_id})`));
      article.append(text(baseline.description));
      const current = effective.get(baseline.part_id);
      article.append(attributeText("Baseline", baseline.attributes));
      if (current) article.append(attributeText("Effective", current.attributes));
      else article.append(message("Effective values not resolved."));
      section.append(article);
    }
    return section;
  }
  function attributeText(label, attributes) {
    const pre = document.createElement("pre");
    pre.textContent = `${label}: ${JSON.stringify(attributes, null, 2)}`;
    return pre;
  }
  function select(label, values) {
    const element = document.createElement("select");
    element.setAttribute("aria-label", label);
    for (const value of values) {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      element.append(option);
    }
    return element;
  }
  function heading(value) {
    const element = document.createElement("h3");
    element.textContent = value;
    return element;
  }
  function message(value) {
    return text(value);
  }
  function text(value) {
    const element = document.createElement("p");
    element.textContent = value;
    return element;
  }
  function styleNode() {
    const style = document.createElement("style");
    style.textContent = `
    .modular-anatomy { color: var(--fg); display: grid; gap: 0.75rem; font: inherit; }
    .modular-anatomy .controls, .modular-anatomy section, .modular-anatomy article { display: grid; gap: 0.5rem; }
    .modular-anatomy button, .modular-anatomy select { color: inherit; background: var(--surface); border: 1px solid var(--border); border-radius: 0.35rem; padding: 0.4rem; }
    .modular-anatomy pre { overflow: auto; color: var(--muted); white-space: pre-wrap; }
    .modular-anatomy .status { align-items: center; display: flex; gap: 0.5rem; justify-content: space-between; }
  `;
    return style;
  }
  function bodyUrl(chatId, subject) {
    return `/api/modular-anatomy/body?chat_id=${encodeURIComponent(chatId)}&subject_kind=${encodeURIComponent(subject.kind)}&subject_id=${encodeURIComponent(subject.id)}`;
  }
  async function requestJson(url, init = {}) {
    const headers = new Headers(init.headers);
    if (init.method && init.method !== "GET") headers.set("x-marinara-csrf", "1");
    const adminSecret = localStorage.getItem("marinara_admin_secret");
    if (adminSecret) headers.set("X-Admin-Secret", adminSecret);
    const response = await fetch(url, { ...init, headers, credentials: "same-origin", cache: "no-store" });
    const payload = await response.json();
    if (!response.ok) {
      const errorPayload = payload;
      throw new Error(errorPayload.error ?? `Request failed with HTTP ${response.status}`);
    }
    return payload;
  }
  if (!customElements.get("marinara-capability-modular-anatomy")) {
    customElements.define("marinara-capability-modular-anatomy", ModularAnatomyElement);
  }
})();
